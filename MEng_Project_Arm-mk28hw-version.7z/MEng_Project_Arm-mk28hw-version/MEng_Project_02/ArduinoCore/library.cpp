/*
 * ArduinoCore.cpp
 *
 * Created: 13/02/2019 13:29:05
 * Author : marotron
 */ 

#include <avr/io.h>


/* Replace with your library code */
int myfunc(void)
{
	return 0;
}

